package dio.webapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
